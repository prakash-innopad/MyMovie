﻿namespace MyMovieApp.Classes
{
    public class EnumManger
    {
        public enum language
        {

        }
    }
}
