﻿namespace MyMovieApp.Models
{
    public class Language
    {
        public int LanguageId { get; set; }

        public string Name { get; set; }

        
    }
}
